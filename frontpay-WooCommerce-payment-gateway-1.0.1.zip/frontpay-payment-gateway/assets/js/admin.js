jQuery( document ).ready(
	function () {
		jQuery( '.form-table' ).append( "<tr valign='top'><td></td><td><a target='_blank' href='https://www.frontpay.pk/'>Sign up Now with frontPay.</a></td></tr>" );

	}
);
