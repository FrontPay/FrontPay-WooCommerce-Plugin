jQuery( document ).ready(
	function () {
		jQuery( '.form-table' ).append( '<tr valign="top"><td></td><td><a target="_blank" href="https://www.frontpay.pk/">Sign up Now with frontPay.</a></td><td></td><td><img src="'+fppg_object.fppg_logo+'" alt="testing title"><p>Powered by FrontPay</p><p>(www.frontpay.pk)</p></td></tr>' );

	}
);
